<?php
error_reporting(E_ALL ^ E_NOTICE);
	include("includes/db.php");
	include("includes/functions.php");
	
	if($_REQUEST['command']=='update'){
		$name=$_REQUEST['name'];
		$email=$_REQUEST['email'];
		$address=$_REQUEST['address'];
		$phone=$_REQUEST['phone'];
		
		$result=mysql_query("insert into customers values('','$name','$email','$address','$phone')");
		$customerid=mysql_insert_id();
		$date=date('Y-m-d');
		$result=mysql_query("insert into orders values('','$date','$customerid')");
		$orderid=mysql_insert_id();
		
		$max=count($_SESSION['cart']);
		for($i=0;$i<$max;$i++){
			$pid=$_SESSION['cart'][$i]['productid'];
			$q=$_SESSION['cart'][$i]['qty'];
			$price=get_price($pid);
			mysql_query("insert into order_detail values ($orderid,$pid,$q,$price)");
		}
		die('Thank You! your order has been placed!');
	}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Bootstrap Admin Theme</title>

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="../dist/css/timeline.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../bower_components/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<script language="javascript">
	function validate(){
		var f=document.form1;
		if(f.name.value==''){
			alert('Your name is required');
			f.name.focus();
			return false;
		}
		f.command.value='update';
		f.submit();
	}
</script>
</head>


<body>

</body>
</html>




</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html"><strong><i>SHOPPING CART</i></strong></a>
            </div>
            <!-- /.navbar-header -->
	<div class="navbar-collapse collapse">
             <ul class="nav navbar-nav navbar-right bootcards-nav-primary">
			 
			    <li>
             <a href="#">
              <i class="fa fa-search"></i>
            </a>
          </li>
		  
		   <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-envelope fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-messages">
                        <li>
                            <a href="#">
                                <div>
                                    <strong>John Smith</strong>
                                    <span class="pull-right text-muted">                                       
                                    </span>
                                </div>
                                <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">
                                <div>
                                    <strong>John Smith</strong>
                                    <span class="pull-right text-muted">                                    
                                    </span>
                                </div>
                                <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">
                                <div>
                                    <strong>John Smith</strong>
                                    <span class="pull-right text-muted">                                       
                                    </span>
                                </div>
                                <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a class="text-center" href="#">
                                <strong>Read All Messages</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
                    </ul>
                    <!-- /.dropdown-messages -->
                </li>		  
          <li class="dropdown">
            <a href="#" class="dropdown-toggle navbar-link" data-toggle="dropdown" role="button" aria-expanded="false">
              <i class="fa fa-globe"></i>
              Languages <span class="caret"></span>
            </a>
            <ul class="dropdown-menu" role="menu">
              <li><a href="#"><i class="fa fa-fw fa-check pull-right"></i>English</a></li>
              <li><a href="#">Hindi</a></li>
            </ul>
          </li><!-- /.dropdown -->      
			</ul>		
		</div>
		
	<div class="navbar-collapse collapse">
        <ul class="nav navbar-nav navbar-right bootcards-nav-primary">
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
              <i class="fa fa-fw fa-home"></i>
               Home
            </a>
            
          </li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
              <i class="fa fa-fw fa-files-o"></i>
              Items
            <span class="caret"></span></a>
            <ul class="dropdown-menu" role="menu">
              <li><a href="#">Elctronics</a></li>
              <li><a href="#">Footwere</a></li>
              <li><a href="#">Fassion</a></li>
			  <li><a href="#">Home Interior</a></li>
              <li><a href="#">Kitchen Appliences</a></li>
              <li><a href="#"></a></li>			  
              <li class="divider"></li>
              <li><a href="#">More...</a></li></ul>
          </li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
              <i class="fa fa-fw fa-briefcase"></i>
              Department Works <span class="caret"></span>
            </a>
            <ul class="dropdown-menu" role="menu">
              <li><a href="#">R.T.O.</a></li>
              <li><a href="#">P.O.</a></li>
              <li><a href="#">Passport Office</a></li>
              <li class="divider"></li>
              <li><a href="#">More</a></li>
            </ul>
          </li>
          <li>
            <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
              <i class="fa fa-fw fa-inr"></i>
              Government Jobs <span class="caret"></span>
            </a>
			<ul class="dropdown-menu" role="menu">
              <li><a href="#"> Action</a></li>
              <li><a href="#"> Another action</a></li>
              <li><a href="#"> Something else here</a></li>
              <li class="divider"></li>
              <li><a href="#">Separated link</a></li>
            </ul>
          </li>
          <li>
            <a href="#">
              <i class="fa fa-fw fa-users"></i>
              About Us
            </a>
          </li>
          
		  <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
						<li>
        			   <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="login.html"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>        
        </ul>
      </div> <!-- /.navbar-top-links -->
	</nav>
        

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="index.html"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Charts<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="flot.html">Flot Charts</a>
                                </li>
                                <li>
                                    <a href="morris.html">Morris.js Charts</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="tables.html"><i class="fa fa-table fa-fw"></i> Tables</a>
                        </li>
                        <li>
                            <a href="forms.html"><i class="fa fa-edit fa-fw"></i> Forms</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-wrench fa-fw"></i> UI Elements<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="panels-wells.html">Panels and Wells</a>
                                </li>
                                <li>
                                    <a href="buttons.html">Buttons</a>
                                </li>
                                <li>
                                    <a href="notifications.html">Notifications</a>
                                </li>
                                <li>
                                    <a href="typography.html">Typography</a>
                                </li>
                                <li>
                                    <a href="icons.html"> Icons</a>
                                </li>
                                <li>
                                    <a href="grid.html">Grid</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-sitemap fa-fw"></i> Multi-Level Dropdown<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="#">Second Level Item</a>
                                </li>
                                <li>
                                    <a href="#">Second Level Item</a>
                                </li>
                                <li>
                                    <a href="#">Third Level <span class="fa arrow"></span></a>
                                    <ul class="nav nav-third-level">
                                        <li>
                                            <a href="#">Third Level Item</a>
                                        </li>
                                        <li>
                                            <a href="#">Third Level Item</a>
                                        </li>
                                        <li>
                                            <a href="#">Third Level Item</a>
                                        </li>
                                        <li>
                                            <a href="#">Third Level Item</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level -->
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-files-o fa-fw"></i> Sample Pages<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="blank.html">Blank Page</a>
                                </li>
                                <li>
                                    <a href="login.html">Login Page</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>		
		
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Forms</h1>
                </div>
                <!-- /.col-lg-12 --><form name="form1" onsubmit="return validate()">
    <input type="hidden" name="command" />
	
	<!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <strong>Custmor Details</strong>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <form role="form">
        
								<table border="0" cellpadding="2px">
									<tr><td>Order Total:</td><td><?php=get_order_total()?></td></tr>
									<tr><td><div class="form-group"><label>Full Name : </label></td><td><input class="form-control" type="text" name="name" /><p class="help-block">Example :- Jhon S. Smith</p><br></td></div></tr>
									<tr><td><div class="form-group"><label>Address : </label></td><td><input class="form-control"  type="text" name="address" /><p class="help-block">Example :- newyork</p><br></td></div></tr>
									<tr><td><div class="form-group"><label>Email@ : </label></td><td><input class="form-control"  type="text" name="email" /><p class="form-control-static">email@example.com</p><br></td></div></tr>
									<tr><td><div class="form-group"><label>Mobile No : </label></td><td><input class="form-control"  class="form-control"  type="text" name="phone" /><br></td></div></tr>
									
									<tr><td><div class="form-group">
                                            <label>Select City : </label> 
                                            <select class="form-control">
                                               <option>Nagpur</option>
                                                <option>Bhandara</option>
                                                <option>Amravati</option>
                                                <option>Chandrapur</option>
                                                <option>Mumbai</option>
												<option>Nashik</option>
												<option>Pune</option>
												<option>Wardha</option>
                                            </select>
									</div></td></tr>										
										
									<tr><td><div class="form-group">
									<label>Delivery Options</label>
									<div class="radio">
									<label>
									<input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>Credit Card
									</label>
									</div>
									<div class="radio">
									<label>
									<input type="radio" name="optionsRadios" id="optionsRadios2" value="option2">Net Banking
									</label>
									</div>
									<div class="radio">
									<label>
									<input type="radio" name="optionsRadios" id="optionsRadios3" value="option3">Cash On Delivery
									</label>
									</div>
									</div></td></tr>								
							
									
									<tr><td>&nbsp;</td><td><button type="submit" class="btn btn-default" value="Place Order" />PlaceOrder</td>
									<td><button type="reset" class="btn btn-default">Reset Button</button></td></tr>
							</table>
						</div>
					</form>
				</form>
            </div>
        </div>
        <!-- /.row (nested) -->
        </div>
        <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        </div>

	</div>
    <!-- /#page-wrapper -->

</div>
    <!-- /#wrapper -->
				<!-- tabbed footer -->
		<div class="navbar navbar-default navbar-bottom">
			<div class="container"><br>
				<div class="bootcards-desktop-footer clearfix">
					<div>
						<span class="pull-left">
							<a>Site Map</a> | <a>Blog</a> | <a> Contact Us</a>
						</span>
						<span class="pull-right"> 
							<i class="fa fa-facebook-official"></i> Facebook
							<i class="fa fa-google-plus"></i> G+
							<i class="fa fa-twitter"></i> Twitter 
						</span>     
					</div><br>
				<div>
					<p class="pull-left">2016 &middot; &copy; Zonictech Software Solutions &middot; All Rights Reserved</p>
					<p class="pull-right"><i class="fa fa-envelope fa-1x"></i> abc@gmail.com</p>
				</div>
			</div>
				<br><br>
			</div>

		</div><!--footer-->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../bower_components/raphael/raphael-min.js"></script>
    <script src="../bower_components/morrisjs/morris.min.js"></script>
    <script src="../js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>


                                                
                                      
                                        
                                        
                                        
                                    























