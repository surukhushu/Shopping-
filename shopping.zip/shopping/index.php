<?php
	header("location:products.php");
?>